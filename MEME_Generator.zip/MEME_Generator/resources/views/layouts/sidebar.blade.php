<!-- Left Sidebar  -->
<div class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li class="nav-devider"></li>
                <li class="nav-label">App Home</li>
                <li> <a href="{{ url('/') }}" aria-expanded="false"><i class="fa fa-cog"></i><span class="hide-menu">MEME Settings</span></span></a>
                </li>
                <li class="nav-label">App Gallery</li>
                <li> <a href="gallery" aria-expanded="false"><i class="fa fa-photo"></i><span class="hide-menu">MEME Gallery</span></a>
                </li>

            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</div>
<!-- End Left Sidebar  -->