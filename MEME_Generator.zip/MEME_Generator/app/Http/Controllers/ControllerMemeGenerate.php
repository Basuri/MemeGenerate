<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ControllerMemeGenerate extends Controller {

    public function getimages() {
        //$images = \File::allFiles(public_path('images'));
        $images = "test";
        //return view('gallery')->with('images', $images);
        
         return view('gallery', compact('images'));
        //print_r($images);
    }

}
